import React, { useState } from 'react';
import { DollarSign, ChevronDown, ChevronRight, Info } from 'lucide-react';

export default function ServiceRates() {
  const [showHolidayRates, setShowHolidayRates] = useState(false);
  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center gap-3 mb-6">
        <DollarSign className="w-6 h-6 text-primary-600" />
        <h2 className="text-2xl font-bold text-gray-900">Service Rates</h2>
      </div>

      <div className="space-y-8">
        {/* Boarding */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Pet Boarding
          </h3>
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-primary-600 font-semibold">
                  Base Rate: $40/night
                </p>
                <ul className="mt-2 space-y-1 text-sm text-gray-600">
                  <li>• Holiday Rate: $55/night (+$15)</li>
                  <li>• Additional Pet: +$32/night</li>
                  <li>• Puppy Rate: $55/night</li>
                </ul>
              </div>
              <div>
                <p className="font-semibold text-gray-700">
                  Extended Care Rates:
                </p>
                <ul className="mt-2 space-y-1 text-sm text-gray-600">
                  <li>• 2-8 additional hours: +50% of nightly rate</li>
                  <li>• 8+ additional hours: +100% of nightly rate</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        {/* Holiday Rate Notice */}
        <div className="bg-blue-50 border border-purple-200 rounded-xl overflow-hidden">
          <button
            onClick={() => setShowHolidayRates(!showHolidayRates)}
            className="w-full px-4 py-3 flex items-center justify-between text-blue-800 hover:bg-purple-100 transition-colors"
          >
            <div className="flex items-center gap-2">
              {showHolidayRates ? (
                <ChevronDown className="w-5 h-5" />
              ) : (
                <ChevronRight className="w-5 h-5" />
              )}
              <span className="font-medium">Click for Drop Off Details</span>
            </div>
          </button>

          {showHolidayRates && (
            <div className="px-4 py-3 border-t border-black-200 bg-white/50">
              <div className="px-4 py-3 border-t border-green-200 bg-white/50">
                <div className="text-sm text-blue-800">
                  <h1 className="text-lg font-bold mb-3">
                    Preparing for Drop-Off at Little Paws Jax
                  </h1>

                  <ol className="list-decimal list-inside space-y-4">
                    <li>
                      <h2 className="font-semibold">
                        Ensure Your Pet is Freshly Washed
                      </h2>
                      <ul className="list-disc list-inside ml-4">
                        <li>
                          Drop-offs are easier when pets are clean and groomed.
                          A recent bath ensures your pet is comfortable and
                          ready for their stay.
                        </li>
                      </ul>
                    </li>
                    <li>
                      <h2 className="font-semibold">
                        Bring Essential Supplies
                      </h2>
                      <ul className="list-disc list-inside ml-4">
                        <li>
                          <strong>Food & Bowls:</strong> Pack enough food for
                          the duration of your pet's stay, along with their
                          feeding bowls. If your pet has special dietary
                          requirements, provide detailed instructions.
                        </li>
                        <li>
                          <strong>Medications:</strong> Bring all necessary
                          medications with clear instructions for dosage and
                          timing.
                        </li>
                        <li>
                          <strong>Toys & Comfort Items:</strong> Include
                          favorite toys, a blanket, or an item that smells like
                          home to help ease your pet's transition.
                        </li>
                        <li>
                          <strong>Kennel or Crate (if necessary):</strong> If
                          your pet is crate-trained or feels secure in their
                          kennel, bring it along for their comfort.
                        </li>
                      </ul>
                    </li>
                    <li>
                      <h2 className="font-semibold">
                        Provide Contact Information
                      </h2>
                      <ul className="list-disc list-inside ml-4">
                        <li>
                          Ensure we have your up-to-date contact information and
                          an emergency contact in case we can't reach you.
                        </li>
                        <li>
                          Share your vet's contact details and any relevant
                          medical history for your pet.
                        </li>
                      </ul>
                    </li>
                    <li>
                      <h2 className="font-semibold">
                        Communicate Your Pet's Routine
                      </h2>
                      <ul className="list-disc list-inside ml-4">
                        <li>
                          Let us know your pet's feeding, exercise, and
                          medication schedule so we can maintain consistency.
                        </li>
                        <li>
                          Inform us of any behavioral quirks or special needs to
                          ensure their safety and happiness.
                        </li>
                      </ul>
                    </li>
                  </ol>

                  <h2 className="text-lg font-bold mt-4 mb-3">At Drop-Off</h2>

                  <ol>
                    <li>
                      <strong>Arrive on Time</strong>
                      <br />• Punctuality helps us provide a smooth transition
                      for your pet and accommodate their needs without
                      disruption.
                    </li>
                    <li>
                      <strong>Review Details with Us</strong>
                      <br />
                      • Go over your pet’s care instructions one final time.
                      <br />• Hand over all supplies, ensuring everything is
                      clearly labeled.
                    </li>
                    <li>
                      <strong>Say Goodbye Calmly</strong>
                      <br />• A relaxed goodbye helps your pet feel secure as
                      they settle into their new environment.
                    </li>
                  </ol>

                  <h2>During the Stay</h2>
                  <p>
                    At Little Paws Jax, we are committed to keeping your pet
                    happy, healthy, and safe. We will provide regular updates to
                    keep you informed about their well-being.
                  </p>
                  <p>
                    By following these guidelines, you ensure your pet has a
                    seamless, comfortable experience at Little Paws Jax.
                  </p>

                  <h2>At Drop-Off</h2>
                  <ol>
                    <li>
                      <strong>Arrive on Time</strong>
                      <br />• Punctuality helps us provide a smooth transition
                      for your pet and accommodate their needs without
                      disruption.
                    </li>
                    <li>
                      <strong>Review Details with Us</strong>
                      <br />
                      • Go over your pet’s care instructions one final time.
                      <br />• Hand over all supplies, ensuring everything is
                      clearly labeled.
                    </li>
                    <li>
                      <strong>Say Goodbye Calmly</strong>
                      <br />• A relaxed goodbye helps your pet feel secure as
                      they settle into their new environment.
                    </li>
                  </ol>

                  <h2>During the Stay</h2>
                  <p>
                    At Little Paws Jax, we are committed to keeping your pet
                    happy, healthy, and safe. We will provide regular updates to
                    keep you informed about their well-being.
                  </p>
                  <p>
                    By following these guidelines, you ensure your pet has a
                    seamless, comfortable experience at Little Paws Jax.
                  </p>

                  {/* You can add the "At Drop-Off" content here if needed */}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Drop-in Visits */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Drop-in Visits
          </h3>
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-primary-600 font-semibold">
                  30-Minute Visit: $22
                </p>
                <ul className="mt-2 space-y-1 text-sm text-gray-600">
                  <li>• Holiday Rate: $37 (+$15)</li>
                  <li>• Additional Dog: +$14</li>
                  <li>• Puppy Rate: $25</li>
                </ul>
              </div>
              <div>
                <p className="text-primary-600 font-semibold">
                  60-Minute Visit: $35
                </p>
                <ul className="mt-2 space-y-1 text-sm text-gray-600">
                  <li>• Holiday Rate: $50 (+$15)</li>
                  <li>• Additional Dog: +$14</li>
                  <li>• Puppy Rate: $38</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Cat Care */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Cat Care (in your home)
          </h3>
          <div className="bg-gray-50 rounded-lg p-4">
            <p className="text-primary-600 font-semibold">
              Base Rate: $20/visit
            </p>
            <ul className="mt-2 space-y-1 text-sm text-gray-600">
              <li>• Holiday Rate: $35 (+$15)</li>
              <li>• Additional Cat: +$8</li>
              <li>• 15+ day bookings: $25/visit</li>
            </ul>
          </div>
        </div>

        {/* Day Care */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Doggy Day Care
          </h3>
          <div className="bg-gray-50 rounded-lg p-4">
            <p className="text-primary-600 font-semibold">Base Rate: $35/day</p>
            <ul className="mt-2 space-y-1 text-sm text-gray-600">
              <li>• Holiday Rate: $50/day (+$15)</li>
              <li>• Additional Dog: +$28</li>
              <li>• Puppy Rate: $39/day</li>
            </ul>
          </div>
        </div>

        {/* Dog Walking */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Dog Walking
          </h3>
          <div className="bg-gray-50 rounded-lg p-4">
            <p className="text-primary-600 font-semibold">
              Base Rate: $25/walk
            </p>
            <ul className="mt-2 space-y-1 text-sm text-gray-600">
              <li>• Holiday Rate: $40/walk (+$15)</li>
              <li>• Additional Dog: +$15</li>
              <li>• Puppy Rate: $28/walk</li>
            </ul>
          </div>
        </div>

        {/* Additional Services */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Additional Services
          </h3>
          <div className="bg-gray-50 rounded-lg p-4">
            <p className="text-primary-600 font-semibold">
              Bathing / Grooming: +$50
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
